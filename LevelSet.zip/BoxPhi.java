package model;

public class BoxPhi extends Phi {
	/**
	 * Creates an iso surface, shaped as a box
	 * @param width The width of the grid
	 * @param height The height of the grid
	 * @param boxHeight The height of the box
	 * @param boxWidth The width of the box
	 * @param centerX The center of the box
	 * @param centerY The center of the box
	 */
	public BoxPhi(int width, int height, float boxHeight, float boxWidth, float centerX, float centerY)
	{
		super(width, height);
		for(int x = 0; x < width; x++)
			for(int y = 0; y < height; y++)
			{
				float xonbox = 0;
				if(x >= centerX - boxHeight / 2 && x <= centerX + boxHeight / 2)
					xonbox = x;
				else
					if(Math.abs(x - centerX - boxHeight / 2) < Math.abs(x - centerX + boxHeight / 2))
						xonbox = centerX + boxHeight / 2;
					else
						xonbox = centerX - boxHeight / 2;
				
				float yonbox = 0;
				if(y >= centerY - boxWidth / 2 && y <= centerY + boxWidth / 2)
					yonbox = y;
				else
					if(Math.abs(y - centerY - boxWidth / 2) < Math.abs(y - centerY + boxWidth / 2))
						yonbox = centerY + boxWidth / 2;
					else
						yonbox = centerY - boxWidth / 2;
				
				float length = (float) Math.sqrt((x - xonbox)*(x - xonbox) + (y - yonbox)*(y - yonbox));
				
				if(x == xonbox && y == yonbox)
				{
					float length1 = -Math.min(y - (centerY - boxWidth / 2), 
								              centerY + boxWidth / 2 - y);
					float length2 = -Math.min(x - (centerX - boxHeight / 2), 
				                              centerX + boxHeight / 2 - x);
					length = Math.max(length1, length2);
				}
				
				grid[x][y] = length;
			}
	}
	public String toString()
	{
		return "Box (" + phicount + ")";
	}
}
