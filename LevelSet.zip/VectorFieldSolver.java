package model;

public class VectorFieldSolver implements Solver {

	VectorField V;
	
	/**
	 * Solves with respect to a vector field. 
	 * One of the uses are to perform Canny edge detection. 
	 * @param V The vector field to follow
	 */
	public VectorFieldSolver(VectorField V)
	{
		this.V = V;
	}
	
	/**
	 * Advects in the direction of the vector field
	 */
	public float solve(Phi phi, int x, int y, float t) {
		float[] grad = gradient(phi, x, y);
		float[] v = V.getVector(x, y, phi);
		
		return (phi.get(x, y) - t*(grad[0]*v[0] + grad[1]*v[1]));
	}

	public float gradientLength(Phi phi, int x, int y) {
		float[] grad = gradient(phi, x, y);
		
		return (float) Math.sqrt(grad[0]*grad[0] + grad[1]*grad[1]);
	}
	
	/**
	 * Uses the upwind scheme
	 * @param phi
	 * @param x
	 * @param y
	 * @return The gradient in the point
	 */
	private float[] gradient(Phi phi, int x, int y)
	{
		float xy = phi.get(x, y);
		float phiXPlus = (phi.get(x + 1, y) - xy);
		float phiXMinus = (xy - phi.get(x - 1, y));
		float phiYPlus = (phi.get(x, y + 1) - xy);
		float phiYMinus = (xy - phi.get(x, y - 1));
		
		float dx, dy;
		
		float[] v = V.getVector(x, y, phi);
		
		if(v[0] < 0)
			dx = phiXPlus;
		else
			dx = phiXMinus;
		
		if(v[1] < 0)
			dy = phiYPlus;
		else
			dy = phiYMinus;

		float[] g = new float[2];
		g[0] = dx;
		g[1] = dy;
		
		return g;
	}

	/**
	 * The maximum advection.
	 */
	public float advection(Phi phi, int x, int y) {
		float[] v = V.getVector(x, y, phi);
		return (float) Math.sqrt(v[0]*v[0] + v[1]*v[1]);
	}
}
