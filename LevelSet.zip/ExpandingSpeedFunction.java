package model;

public class ExpandingSpeedFunction implements SpeedFunction {
	
	/**
	 * A constant expanding function, in the normal direction
	 */
	public float getSpeed(int x, int y, Phi phi)
	{
		return 1;
	}
}
