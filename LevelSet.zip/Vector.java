package model;

/**
 * A simple vector class
 *
 */
public class Vector 
{
	float x, y;
	
	public Vector(float x, float y)
	{
		this.x = x;
		this.y = y;		
	}
	
	public Vector(float[] a)
	{
		x = a[0];
		y = a[1];
	}
	
	public void scale(float scalar)
	{
		x = x * scalar;
		y = y * scalar;
	}

	public float getX()
	{
		return x;
	}
	
	public float getY()
	{
		return y;
	}
	
	public float getLength()
	{
		return (float) Math.sqrt(x*x + y*y);
	}
}
