package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class ClosingAction implements ActionListener
{
	NarrowBandLevelSet ls;
	float d;
	
	public ClosingAction(NarrowBandLevelSet ls, float d)
	{
		this.ls = ls;
		this.d = d;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		ls.closing(d);
		System.out.println("Closing done");
	}
}
