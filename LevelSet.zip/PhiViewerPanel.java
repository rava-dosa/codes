package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.Phi;

public class PhiViewerPanel extends JPanel implements PhiViewer{
	private static float EPSILON = (float) 0.5;
	
	ArrayList<Phi> phis;
	ArrayList<Color> colors;
	
	public PhiViewerPanel(int width, int height)
	{
		phis = new ArrayList<Phi>();
		colors = new ArrayList<Color>();
		setPreferredSize(new Dimension(width, height));
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		int i = 0;
		for(Phi phi: phis)
		{
			g.setColor(colors.get(i));
			i++;
			for(int x = 0; x < phi.getWidth(); x++)
				for(int y = 0; y < phi.getHeight(); y++)
					if(Math.abs(phi.get(x, y)) < EPSILON)
					
						g.drawLine(x, y, x, y);
		}
	}
	
	public void redrawPhi()
	{
		repaint();
	}
	
	public void addPhi(Phi phi, Color color)
	{
		phis.add(phi);
		colors.add(color);
	}
}
