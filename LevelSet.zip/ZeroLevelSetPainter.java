package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.NarrowBand;
import model.NarrowBandLevelSet;
import model.Phi;

public class ZeroLevelSetPainter{
	private static float EPSILON = (float) 1;
	
	public void paint(Graphics g, NarrowBandLevelSet ls, Color c)
	{
		
		ArrayList<int[]> points = ls.getNarrowBand().getPoints();
		Phi phi = ls.getPhi();
		g.setColor(c);		
		int x, y;
		for(int[] p : points)
		{
			x = p[0];
			y = p[1];
			if(Math.abs(phi.get(x, y)) < EPSILON)
				g.drawLine(x, y, x, y);
		}
	}
}
