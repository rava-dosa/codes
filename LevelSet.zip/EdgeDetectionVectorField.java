package model;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class EdgeDetectionVectorField implements VectorField {
	float[][] D;
	
	private static float STANDARD_TRESHOLD = (float) Math.pow(10, 7); 
	
	public EdgeDetectionVectorField(String filename, int width, int height, Phi phi)
	{
		this(new File(filename), width, height, phi);
	}
	
	public EdgeDetectionVectorField(File file, int width, int height, Phi phi)
	{
		this(file, width, height, phi, STANDARD_TRESHOLD, (float)0.5);
	}
	
	/**
	 * Initialises a vector field as described in the report.
	 * In the sample application, one can only use images of size 500 x 500
	 * @param file The file to load the image from (png)
	 * @param width The width of the vector field, the same as the one from the image
	 * @param height The height of the vector field, the same as the one from the image
	 * @param phi Not used TODO: Remove it
	 * @param TRESHOLD The treshold, please consult the report
	 * @param sigma The sigma value to use with the gausian filter, e.g. 0.5
	 */
	public EdgeDetectionVectorField(File file, int width, int height, Phi phi, float TRESHOLD, float sigma)
	{
		BufferedImage image = null;
		BufferedImage image2 = null;
		
		try{
			image = ImageIO.read(file);
			image2 = ImageIO.read(file);
		}
		catch(IOException ex){
			System.out.println("Filen findes ikke");
			System.exit(0);
		}
		
		float maxDist = (float) Math.sqrt(width * width + height * height); 
		
		int k = 2;
		float[][] gausian_filter = new float[2*k + 1][2*k + 1];
		for(int i = 0; i < 2*k + 1; i++)
		{
			for(int j = 0; j < 2*k + 1; j++)
			{
				int ik = i - k;// - 1;
				int jk = j - k;// - 1;
				
				gausian_filter[i][j] = (float) (Math.exp(-(ik*ik + jk*jk) / 2*sigma*sigma) / 2*Math.PI*sigma*sigma);
			}
		}
		
		for(int x = 2; x < width - 2; x++)
			for(int y = 2; y < height - 2; y++)
			{
				float sum = 0;
				for(int i = 0; i < 2*k + 1; i++)
					for(int j = 0; j < 2*k + 1; j++)
						sum += gausian_filter[i][j] * image.getRGB(x - i + k, y - j + k);
				image2.setRGB(x, y, (int)sum);
			}
		
		image = image2;
		
		// Notice that the derivatives aren't well defined at the border
		float[][] A = new float[width][height];
		for(int x = 1; x < width - 1; x++)
		{
			for(int y = 1; y < height - 1; y++)
			{
				float dx = (image.getRGB(x - 1, y) - image.getRGB(x + 1, y)); 
				float dy = (image.getRGB(x, y - 1) - image.getRGB(x, y + 1));
				float norm = (float) Math.sqrt(dx*dx + dy*dy);
				A[x][y] = norm;
			}
		}
		
		float[][] B = new float[width][height];
		for(int x = 1; x < width - 1; x++)
		{
			for(int y = 1; y < height - 1; y++)
			{
				float dx = (image.getRGB(x - 1, y) - image.getRGB(x + 1, y)); 
				float dy = (image.getRGB(x, y - 1) - image.getRGB(x, y + 1));
				float gradLength = (float) Math.sqrt(dx*dx + dy*dy);
				
				float dxA = (A[x - 1][y] - A[x + 1][y]); 
				float dyA = (A[x][y - 1] - A[x][y + 1]);
				
				float product = (dx/gradLength) * dxA + (dy/gradLength) * dyA;  
				
				B[x][y] = product;
			}
		}
		
		float[][] C = new float[width][height];
		for(int x = 1; x < width - 1; x++)
		{
			for(int y = 1; y < height - 1; y++)
			{
				float dx = (image.getRGB(x - 1, y) - image.getRGB(x + 1, y)); 
				float dy = (image.getRGB(x, y - 1) - image.getRGB(x, y + 1));
				float gradLength = (float) Math.sqrt(dx*dx + dy*dy);
				
				float product = (dx/gradLength) * dx + (dy/gradLength) * dy;
				
				C[x][y] = (float) Math.abs(product);
			}
		}
		
		boolean[][] Z = new boolean[width][height];
		for(int x = 1; x < width - 1; x++)
		{
			for(int y = 1; y < height - 1; y++)
			{
				Z[x][y] = false;
				
				if(B[x][y] == 0)
					Z[x][y] = true;
				
				if(B[x][y] < 0)
				{
					if(B[x - 1][y] > 0 || B[x + 1][y] > 0 || B[x][y - 1] > 0 || B[x][y + 1] > 0 ||
							B[x - 1][y - 1] > 0 || B[x + 1][y - 1] > 0 || B[x - 1][y + 1] > 0 || B[x + 1][y + 1] > 0)
						Z[x][y] = true;
				}
			}
		}
		
		D = new float[width][height];
		for(int x = 0; x < width; x++)
		{
			D[x][0] = maxDist;
			D[x][height - 1] = maxDist;
		}
		for(int y = 0; y < height; y++)
		{
			D[0][y] = maxDist;
			D[width - 1][y] = maxDist;
		}
		for(int x = 1; x < width - 1; x++)
		{
			for(int y = 1; y < height - 1; y++)
			{
				// ... if there is an edge
				if(Z[x][y] && C[x][y] > TRESHOLD) 
					D[x][y] = 0;
				else
					D[x][y] = maxDist;
			}
		}
		
		// We recalculate using manhatten distance, which isn't perfect,
		// but it's allright.
		// An alternative strategy would be to use reinitialization 
		D = recalculateDistancesByManhatten(D, 1);
	}
	
	// A debugging function
	//TODO: Fjern?
	public void printMatrix(float[][] matrix, int offX, int offY, int width, int height)
	{
		for(int i = offX; i < offX + width; i++)
		{
			for(int j = offY; j < offY + height; j++)
			{
				System.out.print(matrix[i][j] + "\t");
			}
			System.out.println();
		}		
	}
	
	public float max(float a, float b)
	{
		if(a > b)
			return a;
		else
			return b;
	}
	public float min(float a, float b)
	{
		if(a < b)
			return a;
		else
			return b;
	}
	
	/**
	 * Reinitializes a number of times, to get correct distances in the points
	 * @param D The matrix to reinitialize
	 * @param reinitializations Number of reinitializations
	 * @return The reinitialized matrix
	 */
	public float[][] recalculateDistancesByReinit(float[][] D, int reinitializations)
	{
		float[][] DNew;
		
		int width = D.length;
		int height = D[0].length;
		
		
		for(int i = 0; i < reinitializations; i++)
		{
			DNew = new float[width][height];
			
			for(int x = 1; x < width - 1; x++)
				for(int y = 1; y < height - 1; y++)
				{
					float xy = D[x][y];
					float phiXPlus = (D[x + 1][y] - xy);
					float phiXMinus = (xy - D[x - 1][y]);
					float phiYPlus = (D[x][y + 1] - xy);
					float phiYMinus = (xy - D[x][y - 1]);
					
					float dXSquared = 0;
					float dYSquared = 0;
					
					// The sign of D[x][y] equals the sign of "Sign"
					if(D[x][y] > 0)
					{
						float max = max(phiXMinus, 0);
						float min = min(phiXPlus, 0);
						dXSquared = max(max*max, min*min);
						
						max = max(phiYMinus, 0);
						min = min(phiYPlus, 0);
						dYSquared = max(max*max, min*min);
						
					}
					else 
					{
						float max = max(phiXPlus, 0);
						float min = min(phiXMinus, 0);
						dXSquared = max(max*max, min*min);
						
						max = max(phiYPlus, 0);
						min = min(phiYMinus, 0);
						dYSquared = max(max*max, min*min);
						
					}
					
					float normSquared = dXSquared + dYSquared;
					
					float norm = (float) Math.sqrt(normSquared);
					
					float sign = (float) (D[x][y] / Math.sqrt(D[x][y]*D[x][y] + normSquared));
					
					float t = (float) 0.3; // A stabil CFL condition
					DNew[x][y] = D[x][y] - t * sign*(norm - 1);
				}
			D = DNew;
		}
		
		return D;
	}
	
	/**
	 * Recalculates the distances by assuming the border has distance zero
	 * Uses the Manhatten scheme
	 * @param D The matrix to recalculate
	 * @param iterations The number of recalculations
	 * @return The recalculated matrix
	 */
	public float[][] recalculateDistancesByManhatten(float[][] D, int iterations)
	{
		int width = D.length;
		int height = D[0].length;
		//float maxDist = (float) Math.sqrt(width*width + height*height);
		
		for(int i = 0; i < iterations; i++)
		{
			for(int x = 1; x < width - 1; x++)
			{
				for(int y = 1; y < height - 1; y++)
				{
					float minInArea = D[x - 1][y];
					minInArea = min(minInArea, D[x - 1][y]);
					minInArea = min(minInArea, D[x + 1][y]);
					minInArea = min(minInArea, D[x][y - 1]);
					minInArea = min(minInArea, D[x][y + 1]);
					if(minInArea + 1 < D[x][y])
						D[x][y] = minInArea + 1;
				}
			}
			for(int x = width - 2; x > 1; x--)
				for(int y = height - 2; y > 1; y--)
				{
					float minInArea = D[x - 1][y];
					minInArea = min(minInArea, D[x - 1][y]);
					minInArea = min(minInArea, D[x + 1][y]);
					minInArea = min(minInArea, D[x][y - 1]);
					minInArea = min(minInArea, D[x][y + 1]);
					if(minInArea + 1 < D[x][y])
						D[x][y] = minInArea + 1;
				}
					
					/*
					minInArea = D[x][y];
					float squareRoot = (float) Math.sqrt(2);
					minInArea = min(minInArea, D[x - 1][y - 1]);
					minInArea = min(minInArea, D[x + 1][y + 1]);
					minInArea = min(minInArea, D[x + 1][y - 1]);
					minInArea = min(minInArea, D[x - 1][y + 1]);
					if(minInArea + squareRoot < D[x][y])
						D[x][y] = minInArea + squareRoot;
						*/			
		}
		
		return D;
	}

	public float[] getVector(int x, int y, Phi phi) {
		float dxG = (D[x + 1][y] - D[x - 1][y]) / 2;
		float dyG = (D[x][y + 1] - D[x][y - 1]) / 2;
		
		float[] v = new float[2];
		v[0] = -dxG;
		v[1] = -dyG;
		
		return v;
	}
}
