package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class SafeTranslationAction implements ActionListener
{
	NarrowBandLevelSet ls;
	float time;
	
	public SafeTranslationAction(NarrowBandLevelSet ls, float time)
	{
		this.ls = ls;
		this.time = time;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		ls.safeTranslationInTime(time);
	}
}
