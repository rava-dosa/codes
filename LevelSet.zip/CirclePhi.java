package model;

public class CirclePhi extends Phi 
{
	/**
	 * A circle iso surface
	 * @param width The width of the grid
	 * @param height The height of the grid
	 * @param radius The radius of the circle
	 * @param centerX The center of the circle
	 * @param centerY The center of the circle
	 */
	public CirclePhi(int width, int height, float radius, float centerX, float centerY)
	{
		super(width, height);
		for(int x = 0; x < width; x++)
			for(int y = 0; y < height; y++)
			{
				float length = (float) Math.sqrt((x - centerX)*(x - centerX) + (y - centerY)*(y - centerY));
				grid[x][y] = length - radius;
			}
		phicount = PHICOUNT++;
		System.out.println("new circle");
	}
	
	public String toString()
	{
		return "Circle (" + phicount + ")";
	}
}
