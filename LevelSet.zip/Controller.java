package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.sound.sampled.LineListener;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;

import sun.security.krb5.internal.ktab.l;
import view.AnimationThread;
import view.NarrowBandPainter;
import view.PhiViewer;

import view.Viewer;
import view.ZeroLevelSetPainter;

import view.PhiViewerPanel;
import model.BoxPhi;
import model.CirclePhi;
import model.EdgeDetectionVectorField;
import model.ExpandingSpeedFunction;
import model.ImagePhi;
import model.MorphingSpeedFunction;
import model.MovingVectorField;
import model.NarrowBandLevelSet;
import model.NormalDirectionSolver;
import model.Phi;
import model.ContractingSpeedFunction;
import model.Solver;
import model.SpeedFunction;
import model.VectorField;
import model.VectorFieldSolver;


public class Controller implements ActionListener, MouseMotionListener{
	
	public static int PHIWIDTH = 500;
	public static int PHIHEIGHT = 500;
	
	
	JPanel step, play;
	Viewer viewer;
	JCheckBox stepMax = new JCheckBox("Step max",true);
	JTextComponent stepSize = new JTextField();
	JButton stepButton;
	
	JCheckBox playMax = new JCheckBox("Step max",true);
	JTextComponent playSize = new JTextField();
	JButton playButton;
	
	PlayThread pt;
	JButton playStop;
	
	
	JButton changeSpeedFunction = new JButton("Change Speed Function");
	
	JButton union = new JButton("Union");
	JButton intersect = new JButton("Intersect");
	JButton minus = new JButton("Minus");
	
	JTextField morphot= new JTextField();
	JButton close = new JButton("Morphologic closing");
	JButton open = new JButton("Morphologic opening");
	
	JTextField forwardt= new JTextField();
	JButton forwardb = new JButton("Forward");
	
	
	
	ArrayList<NarrowBandLevelSet> levelSets = new ArrayList<NarrowBandLevelSet>();
	
	DefaultListModel listModel = new DefaultListModel();
	JList list = new JList(listModel);
	JMenuItem jmiCircle;
	JMenuItem jmiBox;
	JMenuItem jmiImage;

	JMenuItem savePic;

	JMenuItem viewNarrowBand;
	JMenuItem viewZeroLevelSet;
	
	
	
	JTextComponent infobox = new JTextField();
	
	
	JPanel window;
	//NarrowBandLevelSet ls;
	
	public static void main(String args[])
	{
		new Controller();
	}
	
	public Controller()
	{		
		Dimension dim = new Dimension(100,20);
		
		infobox.setText("");
		stepSize.setText("");
		playSize.setText("");
		forwardt.setText("");
		forwardt.setPreferredSize(dim);
		morphot.setPreferredSize(dim);
		morphot.setText("");
		LineBorder border = new LineBorder(Color.BLACK);
		
		viewer = new Viewer(PHIWIDTH, PHIHEIGHT);
		//viewer.addPhi(phi, Color.blue);
		//viewer.addPhi(cirklen, Color.red);
		viewer.setBorder(border);


		
		
		viewer.setLevelSets(levelSets);
		//JButton stepButton = new JButton("step");
		//step.addActionListener(new StepAction(ls, (float)0.3));
		
	//Step felt.
		step = new JPanel();
		step.setBorder(border);
		BoxLayout b = new BoxLayout(step,BoxLayout.Y_AXIS);
		step.setLayout(b);
		
		stepMax.addActionListener(this);
		stepSize.setEnabled(false);
		stepButton = new JButton("step");
		stepButton.addActionListener(this);
		
		step.add(new JLabel("Max t:"));
		step.add(stepMax);		
		step.add(stepSize);
		step.add(stepButton);
		
	//Play felt.
		play = new JPanel();
		play.setBorder(border);
		 b = new BoxLayout(play,BoxLayout.Y_AXIS);
		play.setLayout(b);
		
		playMax.addActionListener(this);
		playSize.setEnabled(false);
		playButton = new JButton("Play");
		playButton.addActionListener(this);
		
		play.add(new JLabel("Max t:"));
		play.add(playMax);		
		play.add(playSize);
		play.add(playButton);
		
		JPanel forward = new JPanel();
		forward.setBorder(border); 
	//List
		list.setSize(100,100);
		list.setVisibleRowCount(10);
		JPanel bioppPanel = new JPanel();
		bioppPanel.add(union);
		bioppPanel.add(intersect);
		bioppPanel.add(minus);
		
		JPanel morphoPanel = new JPanel();
		morphoPanel.add(morphot);
		morphoPanel.add(close);
		morphoPanel.add(open);
		
		JPanel forwardPanel = new JPanel();
		forwardPanel.add(forwardt);
		forwardPanel.add(forwardb);
		forwardb.addActionListener(this);
		
		
		//play.addActionListener(new PlayAction(ls, (float)0.3));
		
		playStop = new JButton("Stop");
		playStop.addActionListener(this);
		
		
		viewer.addMouseMotionListener(this);
		

		list = new JList(listModel);
		
		union.addActionListener(this);
		intersect.addActionListener(this);
		minus.addActionListener(this);
		
		
		close.addActionListener(this);
		open.addActionListener(this);
		
		
		changeSpeedFunction.addActionListener(this);
		
		
		window = new JPanel(new BorderLayout());
		JScrollPane scrolllist = new JScrollPane(list);
		scrolllist.setSize(20,20);
		

		window.add(changeSpeedFunction);
		
		window.add(viewer, BorderLayout.CENTER);

		
		JPanel control = new JPanel();
		control.setLayout(new BoxLayout(control, BoxLayout.Y_AXIS));
		control.add(scrolllist);
		
		control.add(bioppPanel);
		control.add(morphoPanel);
		control.add(forwardPanel);
		control.add(changeSpeedFunction);
		
		
		JPanel controlStep = new JPanel();
		controlStep.add(step);
		controlStep.add(play);
		controlStep.add(playStop);
		control.add(controlStep);
		window.add(control, BorderLayout.SOUTH);

		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(window);
		frame.setJMenuBar(generateMenu());
		frame.pack();
		frame.setVisible(true);
		AnimationThread aminator = new AnimationThread(viewer, 50);
		aminator.start();
	}

	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource().equals(stepMax))
		{
			if(stepMax.isSelected())
				stepSize.setEnabled(false);
			else
				stepSize.setEnabled(true);
		}
		if(e.getSource().equals(playMax))
		{
			if(playMax.isSelected())
				playSize.setEnabled(false);
			else
				playSize.setEnabled(true);
		}
		if(e.getSource().equals(stepButton))
		{
			step();				
		}
		if(e.getSource().equals(playButton))
		{
			playButton.setEnabled(false);
			play();
		}
		
		if(e.getSource().equals(playStop))
			if(pt != null)
			{
				pt.play = false;
				playButton.setEnabled(true);
			}
		
		if(e.getSource().equals(jmiCircle))
		{					
			try
			{
				int x,y,r;
				x = Integer.parseInt(askForInput("X"));
				y = Integer.parseInt(askForInput("Y"));
				r = Integer.parseInt(askForInput("Radius"));
				
				Phi phi = new CirclePhi(PHIWIDTH, PHIHEIGHT, r, x, y);
				createLevelSet(phi);
			}
			catch(Exception ex){}
			
		}
		if(e.getSource().equals(jmiBox))
		{
			try
			{
				int x1,y1,x2, y2;
				x2 = Integer.parseInt(askForInput("X - center"));
				y2 = Integer.parseInt(askForInput("Y - center"));
				x1 = Integer.parseInt(askForInput("Width"));
				y1 = Integer.parseInt(askForInput("Height"));
				
				Phi phi = new BoxPhi(PHIWIDTH, PHIHEIGHT, x1, y1, x2, y2);
				createLevelSet(phi);
			}
			catch(Exception ex){}	
		}
		if(e.getSource().equals(jmiImage))
		{
			try
			{
				JFileChooser jfc =  new JFileChooser();
				jfc.showOpenDialog(null);
				

				Phi phi = new ImagePhi(jfc.getSelectedFile(), PHIWIDTH, PHIHEIGHT);
				createLevelSet(phi);
			}
			catch(Exception ex){}
			
		}
		
		if(e.getSource().equals(viewNarrowBand))
		{
			viewer.setPanelType(Viewer.NARROWBAND);
		}
		if(e.getSource().equals(viewZeroLevelSet))
		{
			viewer.setPanelType(Viewer.ZEROLEVELSET);
		}
		if(e.getSource().equals(savePic))
		{
			try{
			JFileChooser jfc =  new JFileChooser();
			jfc.showOpenDialog(null);
			
			int w = viewer.getWidth(), h = viewer.getHeight();
            BufferedImage image = new BufferedImage(w, h,
                BufferedImage.TYPE_INT_RGB);
            Graphics2D g2 = image.createGraphics();
            viewer.paint(g2);
            g2.dispose();
            ImageIO.write(image, "png", jfc.getSelectedFile());
			}catch(Exception ex){}
		}
		if(e.getSource().equals(changeSpeedFunction))
		{
			NarrowBandLevelSet ls = getSelectedLevelSet();
			
			if(ls == null)
				return;
			try{
				SpeedFunction s = askForSpeedFunction(ls.getPhi());
				Solver solver = new NormalDirectionSolver(s);
				ls.getNarrowBand().setSolver(solver);
				
			}catch(Exception ex){}			
		}
		
		if(e.getSource().equals(union))
			biOpp("union");
		if(e.getSource().equals(intersect))
			biOpp("intersect");
		if(e.getSource().equals(minus))
			biOpp("minus");
		
		if(e.getSource().equals(open))
		{
			float t = Float.parseFloat(morphot.getText());
			NarrowBandLevelSet ls = getSelectedLevelSet();
			if(ls != null)
				ls.opening(t);
		}
		
		if(e.getSource().equals(close))
		{
			try{
			float t = Float.parseFloat(morphot.getText());
			NarrowBandLevelSet ls = getSelectedLevelSet();
			if(ls != null)
				ls.closing(t);
			}catch(Exception ex){}
		}
		if(e.getSource().equals(forwardb))
		{
			try{
				float t = Float.parseFloat(forwardt.getText());
				NarrowBandLevelSet ls = getSelectedLevelSet();
				if(ls != null)
					ls.safeTranslationInTime(t);
					
			}catch(Exception ex){System.out.println(ex);}
		}
	}
	
	private void step()
	{
		NarrowBandLevelSet ls = getSelectedLevelSet();
		
		if(ls == null)
			return;
		
		if(stepMax.isSelected())
			ls.stepMax();
		else
			try
			{
				float f = Float.parseFloat(stepSize.getText());
				ls.step(f);
			}
			catch(Exception e){}
	}
	private void play()
	{

		NarrowBandLevelSet ls = getSelectedLevelSet();
		
		if(ls == null)
			return;
		
		if(pt == null || !pt.isAlive())
		{
		if(playMax.isSelected())
		{
			pt = new MaximumPlayThread(ls, 0);
			pt.start();
		}			
		else
			try
			{
				float f = Float.parseFloat(playSize.getText());
				pt = new PlayThread(ls, f, 0);
				pt.start();
			}
			catch(Exception e){System.out.println(e.toString());}
		}
	}
	
	private JMenuBar generateMenu()
	{
		JMenuBar jmb = new JMenuBar();
		JMenu jm = new JMenu("New LevelSet");
		
		jmiCircle = new JMenuItem("Circle");
		jm.add(jmiCircle);
		jmiCircle.addActionListener(this);
		
		jmiBox = new JMenuItem("Box");
		jm.add(jmiBox);
		jmiBox.addActionListener(this);
		
		jmiImage = new JMenuItem("Image");
		jm.add(jmiImage);
		jmiImage.addActionListener(this);
		
		jmb.add(jm);
		
		jm = new JMenu("Save");
		savePic = new JMenuItem("Save picture");
		savePic.addActionListener(this);
		jm.add(savePic);
		jmb.add(jm);
		
		jm = new JMenu("Change view");
		viewNarrowBand = new JMenuItem("Narrow band");
		viewNarrowBand.addActionListener(this);
		jm.add(viewNarrowBand);
		
		viewZeroLevelSet = new JMenuItem("Zero level set");
		viewZeroLevelSet.addActionListener(this);	
		jm.add(viewZeroLevelSet);
		jmb.add(jm);
		
		
		return jmb;
	}
	
	private void addLevelSet(NarrowBandLevelSet ls)
	{
		levelSets.add(ls);
		listModel.addElement(ls);
		list.repaint();
	}

	private void removeLevelSet(NarrowBandLevelSet ls)
	{
		levelSets.remove(ls);
		listModel.removeElement(ls);
		list.repaint();
	}
	
	
	private void createLevelSet(Phi phi) throws Exception
	{
		Solver solver = null;
		
		Object[] possibilities = {"Advection in normal direction", "Advection by vector field"};
		String s = (String)JOptionPane.showInputDialog(null, 
											   "Advection type:",
											   "Advection type",
								                JOptionPane.PLAIN_MESSAGE,
								                null,										   
											   possibilities,
											   "Advection in normal direction");
		if(s.equals("Advection in normal direction"))
		{
			SpeedFunction speed = askForSpeedFunction(phi);
			solver = new NormalDirectionSolver(speed);
		} 
		else
		{
			VectorField V = askForVectorField(phi);
			solver = new VectorFieldSolver(V);
		}
		NarrowBandLevelSet ls = new NarrowBandLevelSet(phi,  solver);
		addLevelSet(ls);		
	}
	private String askForInput(String x)
	{
		 return JOptionPane.showInputDialog(null, x);
	}
	
	private SpeedFunction askForSpeedFunction(Phi phi) throws Exception
	{

		Object[] possibilities = {"Expanding", "Collapsing", "Morphing"};
		String s = (String)JOptionPane.showInputDialog(null, 
											   "Speed function:",
											   "Speed Function",
								                JOptionPane.PLAIN_MESSAGE,
								                null,										   
											   possibilities,
											   "Expanding");
		if(s.equals("Expanding"))
			return new ExpandingSpeedFunction();
		if(s.equals("Collapsing"))
			return new ContractingSpeedFunction();
		if(s.equals("Morphing"))
		{
			return new MorphingSpeedFunction(askForLevelSet().getPhi());
		}
		
		throw new Exception();
	}

	private VectorField askForVectorField(Phi phi) throws Exception
	{

		Object[] possibilities = {"Hoejre", "EdgeDetection"};
		String s = (String)JOptionPane.showInputDialog(null, 
											   "Vector field:",
											   "Vector field",
								                JOptionPane.PLAIN_MESSAGE,
								                null,										   
											   possibilities,
											   "Hoejre");
		if(s.equals("Hoejre"))
		{
			return new MovingVectorField((float)0.5, (float)0.5);
		}
		if(s.equals("EdgeDetection"))
		{
			JFileChooser jfc =  new JFileChooser();
			jfc.showOpenDialog(null);
			
			return new EdgeDetectionVectorField(jfc.getSelectedFile(), PHIWIDTH, PHIHEIGHT, phi);
		}		
		
		throw new Exception();
	}
	
	private NarrowBandLevelSet askForLevelSet()
	{
		NarrowBandLevelSet[] ls = new NarrowBandLevelSet[levelSets.size()];
		for(int i = 0; i < ls.length; i++)
			ls[i] = levelSets.get(i);
		
		return (NarrowBandLevelSet)JOptionPane.showInputDialog(null, 
				                                               "Level Set:",
				                                               "Level Set",
				                                               JOptionPane.PLAIN_MESSAGE,
				                                               null,										   
				                                               ls,
				                                               ls[0]);
	}

	private void biOpp(String op)
	{
		try{
			NarrowBandLevelSet ls1 = getSelectedLevelSet();
			NarrowBandLevelSet ls2 = askForLevelSet();
			Phi phi = ls1.getPhi();
			if(op.equals("union"))			
				phi.union(ls2.getPhi());
			else if(op.equals("intersect"))			
				phi.intersect(ls2.getPhi());
			else if(op.equals("minus"))			
				phi.minus(ls2.getPhi());
			else
				throw new Exception();
			
			removeLevelSet(ls1);
			removeLevelSet(ls2);
			createLevelSet(phi);
		}
		catch(Exception ex){}
	}
	
	private NarrowBandLevelSet getSelectedLevelSet()
	{
		int i = list.getSelectedIndex();
		if(i < 0)
			return null;
		return levelSets.get(i);
	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseMoved(MouseEvent e) {
		
		try
		{
			Phi phi = getSelectedLevelSet().getPhi();
			float value = phi.get(e.getX(), e.getY());
			infobox.setText(Float.toString(value));
		}
		catch(Exception ex)
		{
			infobox.setText("err");
		}
		
	}
}
