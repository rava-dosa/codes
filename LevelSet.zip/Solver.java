package model;

public interface Solver {
	/**
	 * Returns the value in a point when solved with respect
	 * to <code>this</code>.
	 * We do not overwrite the value on the iso surface
	 * @param p The iso surface
	 * @param x 
	 * @param y
	 * @param t the time step
	 * @return the new value in the point.
	 */
	public float solve(Phi p, int x, int y, float t);
	
	/**
	 * The length of the gradient in this point. Probably found using Gudonov
	 * @param phi
	 * @param x
	 * @param y
	 * @return The length of the gradient.
	 */
	public float gradientLength(Phi phi, int x, int y);
	
	/**
	 * The advection size in this point.
	 * Used to find a stabil CFL step size
	 * @param phi
	 * @param x
	 * @param y
	 * @return The advection size
	 */
	public float advection(Phi phi, int x, int y);
}
