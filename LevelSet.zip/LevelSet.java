package model;

public interface LevelSet {
	public void step(float t);
}
