package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class OpeningAction implements ActionListener
{
	NarrowBandLevelSet ls;
	float d;
	
	public OpeningAction(NarrowBandLevelSet ls, float d)
	{
		this.ls = ls;
		this.d = d;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		ls.opening(d);
		System.out.println("Opening done");
	}
}
