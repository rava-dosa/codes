package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import model.LevelSet;

public class StepAction implements ActionListener
{
	LevelSet ls;
	float t;
	
	public StepAction(LevelSet ls, float t)
	{
		this.ls = ls;
		this.t = t;
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		ls.step(t);
		
	}
}
