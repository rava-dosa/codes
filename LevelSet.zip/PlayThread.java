package controller;

import javax.swing.JPanel;

import model.LevelSet;

public class PlayThread extends Thread 
{
	LevelSet ls;
	float t;
	int interval;
	public boolean play = true;
	
	public PlayThread()
	{
	
	}
	public PlayThread(LevelSet ls, float t, int interval)
	{
		this.ls = ls;
		this.t = t;
		this.interval = interval;
	}
	
	public void run()
	{
		while(play)
		{
			ls.step(t);
			try{
				Thread.sleep(interval);
			}catch(Exception e){}
		}
	}

}
