package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.NarrowBand;
import model.NarrowBandLevelSet;
import model.Phi;

public class NarrowBandPainter{
	
	
	public void paint(Graphics g, NarrowBandLevelSet ls)
	{
		ArrayList<int[]> points = ls.getNarrowBand().getPoints();
		
		int x, y;
		for(int[] p : points)
		{
			x = p[0];
			y = p[1];
			if(ls.getNarrowBand().mask[x][y] == 1)
				g.setColor(Color.GREEN);
			else if(ls.getNarrowBand().mask[x][y] == 2)
				g.setColor(Color.RED);
			else
				g.setColor(Color.PINK);		
			g.drawLine(x, y, x, y);
		}
	}
}
