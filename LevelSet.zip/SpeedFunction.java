package model;

public interface SpeedFunction 
{
	/**
	 * Returns the speed in the point, in the normal direction.
	 * Please notice, that a speed function in our framework, only 
	 * depends on the point and the iso surface.
	 * One can think up many more wonderfull speed functions,
	 * that depends on a variaty of parameters.
	 * @param x The point
	 * @param y The point
	 * @param phi The iso surface
	 * @return The speed in the normal direction.
	 */
	public float getSpeed(int x, int y, Phi phi);
}
