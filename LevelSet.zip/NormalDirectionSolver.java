package model;

public class NormalDirectionSolver implements Solver {
	SpeedFunction speed;
	
	/**
	 * Initializes a new solver, with a speed function.
	 * @param speed
	 */
	public NormalDirectionSolver(SpeedFunction speed)
	{
		this.speed = speed;
	}
	
	/**
	 * Solves using the procedure as described in the report
	 */
	public float solve(Phi phi, int x, int y, float t)
	{
		float norm = gradientLength(phi, x, y);
		float a = -speed.getSpeed(x, y, phi);
		return (float) (phi.get(x, y) + a * norm * t);
	}
	
	/**
	 * Calculated using Gudonov
	 */
	public float gradientLength(Phi phi, int x, int y) 
	{
		float xy = phi.get(x, y);
		float phiXPlus = (phi.get(x + 1, y) - xy);
		float phiXMinus = (xy - phi.get(x - 1, y));
		float phiYPlus = (phi.get(x, y + 1) - xy);
		float phiYMinus = (xy - phi.get(x, y - 1));
		
		float a = -speed.getSpeed(x, y, phi);
		
		float dXSquared = 0;
		float dYSquared = 0;
		
		if(a < 0)
		{
			float max = max(phiXMinus, 0);
			float min = min(phiXPlus, 0);
			dXSquared = max(max*max, min*min);
			
			max = max(phiYMinus, 0);
			min = min(phiYPlus, 0);
			dYSquared = max(max*max, min*min);
		}
		else
		{
			float max = max(phiXPlus, 0);
			float min = min(phiXMinus, 0);
			dXSquared = max(max*max, min*min);
			
			max = max(phiYPlus, 0);
			min = min(phiYMinus, 0);
			dYSquared = max(max*max, min*min);
		}
		
		float norm = (float) Math.sqrt(dXSquared + dYSquared);
		return norm;
	}
	
	/**
	 * The maximum advection, conservative estimate
	 */
	public float advection(Phi phi, int x, int y)
	{
		return (float) 2*Math.abs(speed.getSpeed(x, y, phi));
	}
	
	public float max(float a, float b)
	{
		if(a > b)
			return a;
		else
			return b;
	}
	
	public float min(float a, float b)
	{
		if(a < b)
			return a;
		else
			return b;
	}

}
