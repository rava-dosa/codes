package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

import model.NarrowBandLevelSet;
import model.Phi;

public class Viewer extends JPanel 
{
	public static int ZEROLEVELSET = 0;
	public static int NARROWBAND = 1;
	private static float EPSILON = (float) 1;
	public static Color COLORS(int i)
	{
		
	
		Color[] colors = {Color.BLACK,
						  Color.BLUE,
						  Color.RED,
						  Color.GREEN,
						  Color.MAGENTA};
		
		return colors[i % colors.length];
	}
	
	
	ArrayList<NarrowBandLevelSet> levelsets = new ArrayList<NarrowBandLevelSet>();
	int paneltype = ZEROLEVELSET;
	ZeroLevelSetPainter zPainter;
	NarrowBandPainter nbPainter;
	
	public Viewer(int height, int width)
	{
		setPreferredSize(new Dimension(width, height));
		zPainter = new ZeroLevelSetPainter();
		nbPainter = new NarrowBandPainter();
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		int i = 0;
		
		int ptype = paneltype;
		for(NarrowBandLevelSet ls: levelsets)
		{			
			Color c = COLORS(i);
			i++;
			
			if(ptype == ZEROLEVELSET)
				zPainter.paint(g, ls, c);
			if(ptype == NARROWBAND)
				nbPainter.paint(g,ls);
				
		}
			
	}
	
	public void addLevelSet(NarrowBandLevelSet levelset)
	{
		levelsets.add(levelset);
	}
	
	public void setLevelSets(ArrayList<NarrowBandLevelSet> levelsets)
	{
		this.levelsets = levelsets;
	}
	
	public NarrowBandLevelSet[] getLevelSets()
	{
		NarrowBandLevelSet[] ls = new NarrowBandLevelSet[levelsets.size()];
		for(int i = 0; i < ls.length; i++)
			ls[i] = levelsets.get(i);
		
		return ls;	
	}
	
	public void setPanelType(int type)
	{
		paneltype = type;
	}
}
