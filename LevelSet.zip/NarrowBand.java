package model;

import java.util.List;
import java.util.ArrayList;

public class NarrowBand 
{
	Solver solver;
	float gamma;
	ArrayList<Integer> index1;
	ArrayList<Integer> index2;
	public int[][] mask;
	
	/**
	 * The narrow band keeps track of which values to update.
	 * The constructor initializes it
	 * @param phi The iso surface to translate
	 * @param gamma The treshold value for entering the gamma tube
	 * @param solver The solver to use when advecting
	 */
	public NarrowBand(Phi phi, float gamma, Solver solver)
	{
		this.solver = solver;
		this.gamma = gamma;
		index1 = new ArrayList<Integer>();
		index2 = new ArrayList<Integer>();
		mask = new int[phi.getWidth()][phi.getHeight()];
		
		for(int x = 1; x < phi.getWidth() - 1; x++)
			for(int y = 1; y < phi.getHeight() - 1; y++)
			{
				mask[x][y] = 0;
				
				if(Math.abs(phi.get(x, y)) < gamma) 
				{
					mask[x][y] = 2;
					index1.add(x);
					index2.add(y);
				}
			}
		for(int x = 1; x < phi.getWidth() - 1; x++)
			for(int y = 1; y < phi.getHeight() - 1; y++)
			{
				if(mask[x][y] != 2)
				{
					List<int[]> neighbors = getNeighbors(x, y, phi.getWidth(), phi.getHeight());
					for(int[] p: neighbors)
						if(mask[p[0]][p[1]] == 2)
						{						
							mask[x][y] = 1;
							index1.add(x);
							index2.add(y);
							if(phi.get(p[0], p[1]) > 0)
								phi.set(x, y, gamma);
							if(phi.get(p[0], p[1]) < 0)
								phi.set(x, y, -gamma);
							break;
						}
				}
			}
	}
	
	/**
	 * A slow rebuild of the gamma band, shouldn't be used, as
	 * it runs in n squared time
	 * @param phi
	 */
	public void rebuildBands(Phi phi)
	{
		int x, y;
		ArrayList<Integer> index1New = new ArrayList<Integer>();
		ArrayList<Integer> index2New = new ArrayList<Integer>();
		int maskNew[][] = new int[phi.getWidth()][phi.getHeight()];
		
		// rebuild inner band
		for(int i = 0; i < index1.size(); i++)
		{
			x = index1.get(i);
			y = index2.get(i);
		
			if(Math.abs(phi.get(x, y)) < gamma)
			{
				index1New.add(x);
				index2New.add(y);
				maskNew[x][y] = 2;
			}
			else
			{
				if(phi.get(x, y) < 0)
					phi.set(x, y, -gamma);
				else
					phi.set(x, y, gamma);
			}
		}
		
		index1 = index1New;
		index2 = index2New;
		mask = maskNew;
		
		//rebuild safe band
		for(int i = 0; i < index1.size(); i++)
		{
			x = index1.get(i);
			y = index2.get(i);
		
			if(mask[x][y] == 2)
			{
				List<int[]> neighbors = getNeighbors(x, y, phi.getWidth(), phi.getHeight());
				for(int[] p: neighbors)
					if(mask[p[0]][p[1]] == 0)
					{
						index1.add(p[0]);
						index2.add(p[1]);
						mask[p[0]][p[1]] = 1;
						if(phi.get(x, y) > 0)
							phi.set(p[0], p[1], gamma);
						else
							phi.set(p[0], p[1], -gamma);
					}
			}
		}
	}
		
	/**
	 * Reinitializes, the result is placed in <code>phiNew</code>
	 * @param phi The iso surface to reinitialize
	 * @param phiNew The surface to write the result
	 * @param t A CFL safe step to reinitialize, typically 0.3 
	 * @param debug Wheter or not to output debug information
	 */
	public void reinitialize(Phi phi, Phi phiNew, float t, boolean debug)
	{
		if(debug)
			printMatrix(phi, 345, 355, 245, 255);
		for(int i = 0; i < index1.size(); i++)
		{
			int x = index1.get(i);
			int y = index2.get(i);
			if(mask[x][y] == 2)
			{
				float xy = phi.get(x, y);
				
				// Solve the equation using Godunov
				float phiXPlus = (phi.get(x + 1, y) - xy);
				float phiXMinus = (xy - phi.get(x - 1, y));
				float phiYPlus = (phi.get(x, y + 1) - xy);
				float phiYMinus = (xy - phi.get(x, y - 1));
				
				float a = -xy;
				
				float dXSquared = 0;
				float dYSquared = 0;
				
				if(a < 0)
				{
					float max = max(phiXMinus, 0);
					float min = min(phiXPlus, 0);
					dXSquared = max(max*max, min*min);
					
					max = max(phiYMinus, 0);
					min = min(phiYPlus, 0);
					dYSquared = max(max*max, min*min);
				}
				else
				{
					float max = max(phiXPlus, 0);
					float min = min(phiXMinus, 0);
					dXSquared = max(max*max, min*min);
					
					max = max(phiYPlus, 0);
					min = min(phiYMinus, 0);
					dYSquared = max(max*max, min*min);
				} 
				
				float norm = (float) Math.sqrt(dXSquared + dYSquared);
				
				float sign = (xy / (float) (Math.sqrt(xy*xy + norm*norm)));
				
				float d = xy - t*sign*(norm - 1);
				
				phiNew.set(x, y, d);
			}
		}
	}
	
	/**
	 * Clamp the values in the safe band to standard values, not normally needed.
	 * Nice to have when debugging.
	 * @param phi The surface to clamp the values in
	 */
	public void clampValues(Phi phi)
	{
		for(int i = 0; i < index1.size(); i++)
		{
			int x = index1.get(i);
			int y = index2.get(i);
			
			if(phi.get(x, y) < -gamma)
				phi.set(x, y, -gamma);
			if(phi.get(x, y) > gamma)
				phi.set(x, y, gamma);
		}
	}
	
	/**
	 * Recomputes the values in the safe band, using the Manhatten city distance.
	 * The values are fetched from the gamma band
	 * It is critical to call this function, to find out what values should
	 * be placed in the gamma band.
	 * @param phi The surface to update.
	 */
	public void computeCityDistance(Phi phi)
	{
		for(int i = 0; i < index1.size(); i++)
		{
			int x = index1.get(i);
			int y = index2.get(i);
			
			if(mask[x][y] == 1)
			{
				List<int[]> neighbors = getNeighbors(x, y, phi.getWidth(), phi.getHeight());
			
				if(phi.get(x, y) > 0)
				{
					float min = 2*gamma; // A rough minimum, will allways be overwritten
					
					for(int[] p: neighbors)
						if(mask[p[0]][p[1]] == 2)
							if(min > phi.get(p[0], p[1]))
								min = phi.get(p[0], p[1]);
					
					phi.set(x, y, min + 1); 
				}
				else
				{
					float max = -2*gamma; 
					
					for(int[] p: neighbors)
						if(mask[p[0]][p[1]] == 2)
							if(max < phi.get(p[0], p[1]))
								max = phi.get(p[0], p[1]);
					
					phi.set(x, y, max - 1);
				}
			}
		}
	}
	
	/**
	 * Solves the <code>phi</code> iso surface in the gamma band, 
	 * and stores the result in <code>phiNew</code>
	 * @param phi
	 * @param phiNew
	 * @param t the step size (should be choosen using CFL)
	 */
	public void solve(Phi phi, Phi phiNew, float t)
	{
		for(int i = 0; i < index1.size(); i++)
		{
			int x = index1.get(i);
			int y = index2.get(i);
			if(mask[x][y] == 2)
			{
				phiNew.set(x, y, solver.solve(phi, x, y, t));
			}
		}
	}
	
	/**
	 * Finds the maximum step size, according to the CFL condition.
	 * We only look in the gamma band.
	 * @param phi
	 * @return The maximum step to take
	 */
	public float maxTimeStep(Phi phi)
	{
		float max = 0; 
		for(int i = 0; i < index1.size(); i++)
		{
			int x = index1.get(i);
			int y = index2.get(i);
			
			if(mask[x][y] == 2)
			{
				float advection = solver.advection(phi, x, y); 
				if(advection > max)
					max = advection;
			}
		}		
		return (1 / max) / 2;
	}
	
	/**
	 * For debugging
	 * @param phi
	 * @param x1
	 * @param x2
	 * @param y1
	 * @param y2
	 */
	public void	printMatrix(Phi phi, int x1, int x2, int y1, int y2)
	{
		for(int y = y1; y <= y2; y++)
		{
			for(int x = x1; x <= x2; x++)
			{
				String t = Float.toString(phi.get(x,y));
				t += "         ";
				t = t.substring(0,5);
				System.out.print(t +"\t");
			}
			System.out.println();
		}
		System.out.println();System.out.println();System.out.println();
	}

	/**
	 * Locally used to find the neighbor points.
	 * Doesn't return neighbors outside the border, which is a nice thing :D
	 * @param x
	 * @param y
	 * @param maxWidth
	 * @param maxHeight
	 * @return A list of neighbor points
	 */
	public List<int[]> getNeighbors(int x, int y, int maxWidth, int maxHeight)
	{
		List<int[]> points = new ArrayList<int[]>(8);
		
		int[] p;
		
		if(x > 0)
		{
			if(y > 0)
			{
				p = new int[2];
				p[0] = x - 1; p[1] = y - 1;
				points.add(p);
			}
			p = new int[2];
			p[0] = x - 1; p[1] = y;
			points.add(p);
		
			if(y + 1 < maxHeight)
			{
				p = new int[2];
				p[0] = x - 1; p[1] = y + 1;
				points.add(p);
			}
		}
		
		if(y > 0)
		{
			p = new int[2];
			p[0] = x; p[1] = y - 1;
			points.add(p);
		}
	
		if(y + 1 < maxHeight)
		{
			p = new int[2];
			p[0] = x; p[1] = y + 1;
			points.add(p);
		}		

		if(x + 1 < maxWidth)
		{
			if(y > 0)
			{
				p = new int[2];
				p[0] = x + 1; p[1] = y - 1;
				points.add(p);
			}
			p = new int[2];
			p[0] = x + 1; p[1] = y;
			points.add(p);
		
			if(y + 1 < maxHeight)
			{
				p = new int[2];
				p[0] = x + 1; p[1] = y + 1;
				points.add(p);
			}
		}
		
		return points;
	}

	public Solver getSolver()
	{
		return solver;
	}
	
	public void setSolver(Solver solver)
	{
		this.solver = solver;
	}
	
	/**
	 * Returns a copy the points in the gamma band together with the safe tube
	 * Used for viewing the gamma band. 
	 * @return A list of points
	 */
	public ArrayList<int[]> getPoints()
	{
		ArrayList<int[]> points = new ArrayList<int[]>();
		for(int i = 0; i < index2.size(); i++)
		{
			try{
				int[] x = {index1.get(i), index2.get(i)};
				points.add(x);
			}catch(Exception e){}
		}		
		return points;
	}

	public float max(float a, float b)
	{
		if(a > b)
			return a;
		else
			return b;
	}
	
	public float min(float a, float b)
	{
		if(a < b)
			return a;
		else
			return b;
	}
	
}
