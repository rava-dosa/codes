package model;

public class Phi 
{
	float[][] grid;
	static int PHICOUNT = 1;
	int phicount;
	
	public Phi(int width, int height)
	{
		phicount = PHICOUNT++;
		grid = new float[width][height];
	}
	
	public Phi(Phi phi)
	{
		this(phi.getWidth(), phi.getHeight());
		for(int x = 0; x < phi.getWidth(); x++)
			for(int y = 0; y < phi.getHeight(); y++)
				grid[x][y] = phi.get(x, y);
	}
	
	public float get(int x, int y)
	{
		return grid[x][y];		
	}
	
	public void set(int x, int y, float v)
	{
		grid[x][y] = v;	
	}

	public int getWidth()
	{
		return grid.length;
	}
	
	public int getHeight()
	{
		return grid[0].length;
	}
	
	/**
	 * <code>this</code> becomes the union of <code>this</code>
	 * and the parameter <code>phi</code>
	 * Assumes that the two iso surfaces has the same grid size
	 * @param phi The iso surface to union with
	 */
	public void union(Phi phi)
	{
		for(int x = 0; x < getWidth(); x++)
			for(int y = 0; y < getHeight(); y++)
				if(get(x, y) > phi.get(x, y))
					grid[x][y] = phi.get(x, y);			
	}
	
	/**
	 * <code>this</code> becomes the intersection of <code>this</code>
	 * and the parameter <code>phi</code>
	 * Assumes that the two iso surfaces has the same grid size
	 * @param phi The iso surface to intersect with
	 */
	public void intersect(Phi phi)
	{
		for(int x = 0; x < getWidth(); x++)
			for(int y = 0; y < getHeight(); y++)
				if(get(x, y) < phi.get(x, y))
					grid[x][y] = phi.get(x, y);			
	}
	
	/**
	 * Removes <code>phi</code> from <code>this</code>
	 * Assumes that the two iso surfaces has the same grid size
	 * @param phi The iso surface to remove
	 */
	public void minus(Phi phi)
	{
		for(int x = 0; x < getWidth(); x++)
			for(int y = 0; y < getHeight(); y++)
				if(get(x, y) < -phi.get(x, y))
					grid[x][y] = -phi.get(x, y);
	}

	/**
	 * Reinitializes in all points EXCEPT THE BORDER
	 * Mainly used when creating iso-surfaces from raw images.
	 * NOT edge detection
	 * Please consult the report for further information
	 * @param width the width of <code>this</code>
	 * @param height the height of <code>this</code>
	 * @param reinitializations the number of reinitializations
	 */
	public void renormalize(int width, int height, int reinitializations)
	{
		float maxVal = (float) Math.sqrt(width * width + height * height);
		
        float[][] newGrid;
        
        for(int i = 0; i < reinitializations; i++)
        {
        	newGrid = new float[width][height];
        	
        	for(int x = 0; x < width; x++)
        	{
        		newGrid[x][0] = maxVal;
        		newGrid[x][height - 1] = maxVal;
        	}
        	for(int y = 0; y < height; y++)
        	{
        		newGrid[0][y] = maxVal;
        		newGrid[width - 1][y] = maxVal;
        	}
        		
        	for(int x = 1; x < width - 1; x++)
        		for(int y = 1; y < height - 1; y++)
        		{
        			float xy = get(x, y);
        			float phiXPlus = (get(x + 1, y) - xy);
        			float phiXMinus = (xy - get(x - 1, y));
        			float phiYPlus = (get(x, y + 1) - xy);
        			float phiYMinus = (xy - get(x, y - 1));
        			
        			float dXSquared = 0;
        			float dYSquared = 0;
       
        			// Please notice that the sign of "Sign" is the same as that of "grid"
        			// Please consult the report for further information
        			if(grid[x][y] > 0)
        			{
        				float max = max(phiXMinus, 0);
        				float min = min(phiXPlus, 0);
        				dXSquared = max(max*max, min*min);
        				
        				max = max(phiYMinus, 0);
        				min = min(phiYPlus, 0);
        				dYSquared = max(max*max, min*min);
        				
        			}
        			else 
        			{
        				float max = max(phiXPlus, 0);
        				float min = min(phiXMinus, 0);
        				dXSquared = max(max*max, min*min);
        				
        				max = max(phiYPlus, 0);
        				min = min(phiYMinus, 0);
        				dYSquared = max(max*max, min*min);
        				
        			}
        			
        			float normSquared = dXSquared + dYSquared;

        			float norm = (float) Math.sqrt(normSquared);

        			//Uses the sign from slide handout by Ken Museth
        			float sign = (float) (grid[x][y] / Math.sqrt(grid[x][y]*grid[x][y] + normSquared));
        			
        			float t = (float) 0.3; // A stabil CFL condition
        			newGrid[x][y] = grid[x][y] - sign*(norm - 1)*t;
        		}
        	grid = newGrid;
        }   
	}
	
    public float max(float a, float b)
	{
		if(a > b)
			return a;
		else
			return b;
	}
	
	public float min(float a, float b)
	{
		if(a < b)
			return a;
		else
			return b;
	}
	
}

