package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class MaximumPlayAction implements ActionListener
{
	NarrowBandLevelSet ls;
	int interval;
	
	public MaximumPlayAction(NarrowBandLevelSet ls, int interval)
	{
		this.ls = ls;
		this.interval = interval;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		Thread pt = new MaximumPlayThread(ls, interval);
		pt.start();
		System.out.println("done");
	}
}
