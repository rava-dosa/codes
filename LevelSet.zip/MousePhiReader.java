package controller;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.text.JTextComponent;

import model.Phi;

public class MousePhiReader implements MouseMotionListener {
	Phi phi;
	JTextComponent infobox;

	public MousePhiReader(Phi phi, JTextComponent infobox)
	{	
		this.phi = phi;
		this.infobox = infobox;
	}	
	
	public void mouseDragged(MouseEvent e) {

	}

	public void mouseMoved(MouseEvent e) {
		float value = phi.get(e.getX(), e.getY());
		infobox.setText(Float.toString(value));
	}

}
