package model;

public class MovingVectorField implements VectorField {

	float[] v;
	
	/**
	 * A very simple vector field, all vectors are defined by these parameters
	 * @param x The direction in the x-axis
	 * @param y The direction in the y-axis 
	 */
	public MovingVectorField(float x, float y)
	{
		v = new float[2];
		v[0] = x;
		v[1] = y;
	}
	
	/**
	 * Returns the obvious vector
	 */
	public float[] getVector(int x, int y, Phi phi) {
		return v;
	}

}
