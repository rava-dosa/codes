package model;

public class ContractingSpeedFunction implements SpeedFunction {
	
	/**
	 * The speed in a point is constant along the normal, towards the center
	 * of the iso surface
	 */
	public float getSpeed(int x, int y, Phi phi) 
	{
		return -1;
	}
}
