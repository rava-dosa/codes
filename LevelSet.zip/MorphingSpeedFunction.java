package model;

public class MorphingSpeedFunction implements SpeedFunction {
	Phi target;
	
	/**
	 * The target we wan't to morph into.
	 * Remember that the iso surfaces must be overlapping
	 * @param phi Should be removed TODO: Fjern
	 * @param target
	 */
	public MorphingSpeedFunction(Phi target)
	{
		this.target = target;
	}
	
	/**
	 * Uses a stabil morphing method.
	 */
	public float getSpeed(int x, int y, Phi phi)
	{
		return phi.get(x, y) - target.get(x, y);
	}

}
