package model;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImagePhi extends Phi {
	public ImagePhi(String filename, int width, int height)
	{
		this(new File(filename), width, height);
	}
	
	/**
	 * Loads a raw image file as described in the notes.
	 * Please consult the report
	 * Sets the outside to a maximum constant, and the inside to a 
	 * negative minimum. We then reinitialize to recalculate the
	 * distances
	 * @param file The image to load, has to have the same dimensions as width and height
	 * @param width The width of the grid
	 * @param height The height of the grid
	 */
	public ImagePhi(File file, int width, int height)
	{
		super(width, height);

		BufferedImage image = null;

		try{
            image = ImageIO.read(file);
        }
        catch(IOException ex){
            System.out.println("The file " + file + " wasn't found");
            System.exit(0);
        }

        float c = (float) Math.sqrt(width * width + height * height);
        
        int w = Math.min(image.getWidth(), width);
        int h = Math.min(image.getHeight(), height);
        for(int x = 0; x < w; x++)
        	for(int y = 0; y < h; y++)
        	{
        		int color = image.getRGB(x, y);
        		
        		if(color == -1)
        		{
        			grid[x][y] = c;
        		}
        		else
        			grid[x][y] = -c;
        	}
        
        renormalize(width, height, 30);
	}
}
