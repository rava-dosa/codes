package model;

public class NarrowBandLevelSet implements LevelSet {
	Phi phi;
	NarrowBand nb;
	Phi phiNew;
	
	/**
	 * Initializes a new narrow band with a gamme of three.
	 * @param phi The iso surface we are going to advect
	 * @param solver The solver to respect
	 */
	public NarrowBandLevelSet(Phi phi, Solver solver)
	{
		this.phi = phi;
		nb = new NarrowBand(phi, 3, solver); // gamma is 3
		phiNew = new Phi(phi);
	}
	
	public NarrowBand getNarrowBand()
	{
		return nb;
	}
	
	public Phi getPhi()
	{
		return phi;
	}
	
	/**
	 * Perform a step, by solving, reinitializing three times,
	 * compute the city distance, clamp the values, and finally
	 * rebuild the band.
	 */
	public void step(float t) 
	{
		nb.solve(phi, phiNew, t);
		
		Phi tmp = phi;
		phi = phiNew;
		phiNew = tmp;
		
		for(int i = 0; i < 3; i++)
		{
			nb.reinitialize(phi, phiNew, t, false);
			
			tmp = phi;
			phi = phiNew;
			phiNew = tmp;
		}
		
		nb.computeCityDistance(phi);
		
		nb.clampValues(phi);		
		
		nb.rebuildBands(phi);
	}

	/**
	 * Perform a maximum step
	 *
	 */
	public void stepMax()
	{
		step(nb.maxTimeStep(phi));
	}

	/**
	 * Advects the surface forward in time, by taking safe steps, accroding to CFL
	 * @param time The time into the future we wish to advect
	 */
	public void safeTranslationInTime(float time)
	{
		while(time > 0)
		{
			float maxTimeStep = nb.maxTimeStep(phi);
			step(Math.min(time, maxTimeStep));
			time -= maxTimeStep;
		}
	}
	
	/**
	 * Performs a morphological opening of size <code>d</code>
	 * @param d The size to collapse, before expanding 
	 */
	public void opening(float d)
	{
		
		Solver oldSolver = nb.getSolver();
		Solver normalDirectionSolver = new NormalDirectionSolver(new ContractingSpeedFunction());
		nb.setSolver(normalDirectionSolver);
		safeTranslationInTime(d);
		
		normalDirectionSolver = new NormalDirectionSolver(new ExpandingSpeedFunction());
		nb.setSolver(normalDirectionSolver);
		safeTranslationInTime(d);
		
		nb.setSolver(oldSolver);
	}
	
	/**
	 * Performs a morphological closing of size <code>d</code>
	 * @param d The distance to expand, before collapsing
	 */
	public void closing(float d)
	{
		Solver oldSolver = nb.getSolver();
		
		Solver normalDirectionSolver = new NormalDirectionSolver(new ExpandingSpeedFunction());
		nb.setSolver(normalDirectionSolver);
		safeTranslationInTime(d);
		
		normalDirectionSolver = new NormalDirectionSolver(new ContractingSpeedFunction());
		nb.setSolver(normalDirectionSolver);
		safeTranslationInTime(d);
		
		nb.setSolver(oldSolver);
	}
	
	public String toString()
	{
		return "NB: " + phi;
	}
}
