package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.LevelSet;

public class PlayAction implements ActionListener
{
	LevelSet ls;
	float t;
	
	public PlayAction(LevelSet ls, float t)
	{
		this.ls = ls;
		this.t = t;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		Thread pt = new PlayThread(ls, t, 100);
		pt.start();
		System.out.println("done");
	}
}
