package view;

import java.util.ArrayList;

import javax.swing.JPanel;

public class AnimationThread extends Thread 
{
	ArrayList<JPanel> panels;
	int interval;
	
	public AnimationThread(JPanel panel, int interval)
	{
		panels = new ArrayList<JPanel>();
		panels.add(panel);
		//this.panel = panel;
		this.interval = interval;
	}
	
	public void addPanel(JPanel panel)
	{
		panels.add(panel);
	}
	
	public void run()
	{
		while(true)
		{
			for(JPanel panel : panels)
				panel.repaint();
			try{
				Thread.sleep(interval);
			}catch(Exception e){}
		}
	}

}
