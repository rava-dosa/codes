package view;

import java.awt.Color;
import model.Phi;

public interface PhiViewer {
	public void redrawPhi();
	public void addPhi(Phi phi, Color color);
}
