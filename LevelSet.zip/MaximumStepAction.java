package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class MaximumStepAction implements ActionListener
{
	NarrowBandLevelSet nbls;
	
	public MaximumStepAction(NarrowBandLevelSet nbls)
	{
		this.nbls = nbls;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		nbls.stepMax();
		
	}
}
