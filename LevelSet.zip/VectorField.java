package model;

public interface VectorField {
	/**
	 * Please notice, that a vector can only depend on the 
	 * point and the surface.
	 * One can imagine many vectorfields, depending on many 
	 * other parameters
	 * @param x the point
	 * @param y the point
	 * @param phi the iso surface
	 * @return the vector with respect to which one whishes to advect
	 */
	public float[] getVector(int x, int y, Phi phi);
}
