package controller;

import javax.swing.JPanel;

import model.LevelSet;
import model.NarrowBandLevelSet;

public class MaximumPlayThread extends PlayThread 
{
	NarrowBandLevelSet ls;
	int interval;
	
	public MaximumPlayThread(NarrowBandLevelSet ls, int interval)
	{
		this.ls = ls;
		this.interval = interval;
	}
	
	public void run()
	{
		while(play)
		{
			ls.stepMax();
			if(interval > 0)
				try{
					Thread.sleep(interval);
				}catch(Exception e){}
		}
	}

}
