package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

import model.NarrowBand;
import model.Phi;

public class PhiViewerPanelInShades extends JPanel implements PhiViewer{
	private static float EPSILON = (float) 1;
	
	Phi phi;
	NarrowBand nb;
	
	public PhiViewerPanelInShades(Phi phi, NarrowBand nb)
	{
		this.nb = nb;
		this.phi = phi;
		setPreferredSize(new Dimension(phi.getWidth(), phi.getHeight()));
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		float maxDist = (float) Math.sqrt(phi.getWidth() * phi.getWidth() + phi.getHeight() * phi.getHeight());
		float factor = (float) 255.0 / maxDist;
		//System.out.println(factor);
		
		for(int x = 0; x < phi.getWidth(); x++)
			for(int y = 0; y < phi.getHeight(); y++)
			{
				if(nb.mask[x][y] == 2)
					g.setColor(Color.red);
				else if(nb.mask[x][y] == 1)
					g.setColor(Color.green);
				else 
					if(phi.get(x,y) >= 0)
					g.setColor(Color.black);
				else if(phi.get(x,y) <= 0)
					g.setColor(Color.cyan);
				else
					g.setColor(Color.white);
				
				
				g.drawLine(x, y, x, y);
				
				
			
				/*
				try{
				float dist = Math.abs(phi.get(x, y));
				//System.out.println(factor * dist);
				int v = (int) (factor * dist);
				Color c = new Color(v, v, v);
				g.setColor(c);
				g.drawLine(x, y, x, y);
				} catch (Exception e) {
					g.setColor(Color.green);
					g.drawLine(x, y, x, y);
				}
				*/
			}
					
	}
	
	public void redrawPhi()
	{
		repaint();
	}
	

	public void addPhi(Phi phi, Color color) {
		// TODO Auto-generated method stub
		
	}
}
