#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  cimg_usage("Level Set example");
  const char* input = cimg_option("-i","ima/shape.pgm","Input image");

  const double level_curve    = cimg_option("-level",100.0,"Level curve");
  const int nb_iter           = cimg_option("-it",3000,"Number of Iterations");
  const double dt             = cimg_option("-dt",0.2,"Time step (if negative, automatic selection)");
  const int df_frequency_iter = cimg_option("-df_freq",50,"Frequency of update as a number of iterations");
  const int df_nb_iter     = cimg_option("-df_it",30,"Number of PDE iterations");
  const double df_dt          = cimg_option("-df_dt",0.1,"Time step");

  CImg<float> img(input);
  CImgDisplay disp(img,"Distance function");
  
  //img.get_perona_malik2d(itm,dt,dta,&disp);
  img.get_mean_curvature_motion(level_curve,nb_iter,dt,df_frequency_iter,df_nb_iter,df_dt,&disp);

  img.display(disp);
  while (!disp.closed) disp.wait();

  return 0;
}
