#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  const char* input = cimg_option("-i","Heat.pgm","Input image");
  const double dt   = cimg_option("-dt",0.25,"Time step (if negative, automatic selection)");
  const int itm     = cimg_option("-it",50,"Number of Iterations");

  CImg<float> img(input);
  CImgDisplay disp(img,"heat flow");
  
  img.get_isotropic2d(itm,dt,&disp);
  
  while (!disp.closed) disp.wait();

  return 0;
}
