/*-------------------------------------------------------------------
  
  File        : PDE.h
  
  Description : CImg plugin that implements several diffusion PDE's

  Copyright   : David Tschumperle
                ( http://www.greyc.ensicaen.fr/~dtschump/ )
   
  This software is governed by the CeCILL  license under French law and
  abiding by the rules of distribution of free software.  You can  use, 
  modify and/ or redistribute the software under the terms of the CeCILL
  license as circulated by CEA, CNRS and INRIA at the following URL
  "http://www.cecill.info". 
  
  As a counterpart to the access to the source code and  rights to copy,
  modify and redistribute granted by the license, users are provided only
  with a limited warranty  and the software's aupas chez moi, et je n'arrive pas a trouver le repertoithor,  the holder of the
  economic rights,  and the successive licensors  have only  limited
  liability. 
  
  In this respect, the user's attention is drawn to the risks associated
  with loading,  using,  modifying and/or developing or reproducing the
  software by the user in light of its specific status of free software,
  that may mean  that it is complicated to manipulate,  and  that  also
  therefore means  that it is reserved for developers  and  experienced
  professionals having in-depth computer knowledge. Users are therefore
  encouraged to load and test the software's suitability as regards their
  requirements in conditions enabling the security of their systems and/or 
  data to be ensured and,  more generally, to use and operate it in the 
  same conditions as regards security. 
  
  The fact that you are presently reading this means that you have had
  knowledge of the CeCILL license and that you accept its terms.
  
  Author: Pierre Kornprobst
	( http://www-sop.inria.fr/members/Pierre.Kornprobst/index.shtml )

  Content: 
	- Toolbox
	- Image restoration
	- Level-sets and segmentation
	- Some applications

--------------------------------------------------------------------*/

/** *****************************************************************

TOOLBOX

***************************************************************** **/

//! Weight for the Total Variation diffusion equation
static double weight_tv(double u,double eps) { return 1.0/std::sqrt(eps+u*u); }

//! Weight for the Perona-Malik diffusion equation (from Geman-Reynolds)
static double weight_perona_malik(double u) { return 1.0/std::pow(1.0+u*u,2.0); }

//! Returns positive part
static double positive_part(double x) { return x>=0.0?x:0.0; }

//! Returns negative part ()
static double negative_part(double x) { return x<=0.0?x:0.0; }

//! Returns minmod ()
static double minmod(double x, double y) { return (x*y)>0.0?cimg::sign(x)*cimg::min(std::fabs(x),std::fabs(y)):0.0; }

//! Returns edge_detector function for active contours ()
static double edge_detector(double x) { return 1.0 / (1.0 + x*x); }

//! Returns L2 norm (sqrt(x^2+y^2))
static double vector_norm(double x,double y) { return std::pow(std::pow(x,2.0)+std::pow(y,2.0),0.5); }

//! Returns the curvature of an image
CImg<T> get_curvature() const {
  CImg<double> img(*this),curvature(*this);
  double dx,dy,dxx,dyy,dxy,gnorm;

    cimg_mapXY(img,x,y) {

	dx = 0.5*(img.neumann_pix2d(x+1,y)-img.neumann_pix2d(x-1,y));
	dy = 0.5*(img.neumann_pix2d(x,y+1)-img.neumann_pix2d(x,y-1));
	gnorm = vector_norm(dx,dy);

	if(gnorm < 1e-5) curvature(x,y) = 0.0;
	else{	
		dxx = img.neumann_pix2d(x+1,y)-2.0*img(x,y)+img.neumann_pix2d(x-1,y);
		dyy = img.neumann_pix2d(x,y+1)-2.0*img(x,y)+img.neumann_pix2d(x,y-1);
		dxy = 0.25*(img.neumann_pix2d(x+1,y+1)+img.neumann_pix2d(x-1,y-1)-img.neumann_pix2d(x+1,y-1)-img.neumann_pix2d(x-1,y+1));
		curvature(x,y) = (dxx*dy*dy-2*dxy*dx*dy+dyy*dx*dx) / std::pow(gnorm,2.0);
	    }
	}
  return curvature;
}

/** *****************************************************************

IMAGE RESTORATION

***************************************************************** **/

//! 2D isotropic smoothing with the classical heat flow PDE
/**
   Return an image that has been smoothed by the classical isotropic heat flow PDE
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.
**/
CImg<T> get_isotropic2d(const int nb_iter=100, const float dt=0, CImgDisplay *disp=NULL) const {
  CImg<float> img(*this), veloc(*this,false);
  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) cimg_map3x3(img,x,y,0,k,I) {
      const float
	ixx = Inc + Ipc - 2*Icc,
	iyy = Icn + Icp - 2*Icc;
      veloc(x,y,k) = ixx + iyy; // Laplacian of I
    }
    
    float xdt = dt;
    if (dt<0) { 
      CImgStats stats(veloc,false);
      xdt = -dt/cimg::abs(cimg::max(stats.min,stats.max));
    }
    
    // Next iterate
    img+=xdt*veloc;
   
    if (disp) {
      if (disp->resized) disp->resize();
      img.display(*disp);
    }
  }
  
  return img;
}

//! 2D Total Variation equation
/**
   Returns an image that has been smoothed by the Perona-Malik flow PDE
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param delta = Discontinuity parameter
   \param eps = Approximation of fabs(s) by sqrt(eps+s*s) because fabs function is not differentiable. eps should be small.
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.
**/
CImg<T> get_tv2d(const int nb_iter=100, const float dt=0, const float delta=30.0, const float eps=1.0, CImgDisplay *disp=NULL) const {
  CImg<float> img(*this), veloc(*this,false);
  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) 
      cimg_map3x3(img,x,y,0,k,I)
        veloc(x,y,k) = 
          weight_tv((Inc-Icc)/delta,eps)*(Inc-Icc)
        + weight_tv((Ipc-Icc)/delta,eps)*(Ipc-Icc)
        + weight_tv((Icn-Icc)/delta,eps)*(Icn-Icc)
        + weight_tv((Icp-Icc)/delta,eps)*(Icp-Icc);
  
  float xdt = dt;
    if (dt<0) { 
      CImgStats stats(veloc,false);
      xdt = -dt/cimg::abs(cimg::max(stats.min,stats.max));
    }
    
    img+=xdt*veloc;
   
    if (disp) {
      if (disp->resized) disp->resize();
      img.display(*disp);
    }
  }
  
  return img;
}

//! 2D Perona-Malik equation
/**
   Returns an image that has been smoothed by the Perona-Malik flow PDE
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param delta = Discontinuity parameter
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.
**/
CImg<T> get_perona_malik2d(const int nb_iter=100, const float dt=0, const float delta=30.0, CImgDisplay *disp=NULL) const {
  CImg<float> img(*this), veloc(*this,false);
  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) 
      cimg_map3x3(img,x,y,0,k,I)
        veloc(x,y,k) = 
          weight_perona_malik((Inc-Icc)/delta)*(Inc-Icc)
        + weight_perona_malik((Ipc-Icc)/delta)*(Ipc-Icc)
        + weight_perona_malik((Icn-Icc)/delta)*(Icn-Icc)
        + weight_perona_malik((Icp-Icc)/delta)*(Icp-Icc);
  
  float xdt = dt;
    if (dt<0) { 
      CImgStats stats(veloc,false);
      xdt = -dt/cimg::abs(cimg::max(stats.min,stats.max));
    }
    
    img+=xdt*veloc;
   
    if (disp) {
      if (disp->resized) disp->resize();
      img.display(*disp);
    }
  }
  
  return img;
}

//! Shock Filters equation
/**
   Returns an image that has been enhanced by the Shock-Filters flow PDE
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.
**/
CImg<T> get_shock_filters(const int nb_iter=100, const float dt=0, CImgDisplay *disp=NULL) const {
  CImg<float> img(*this), veloc(*this,false);
  double dx,dy,dxn,dxp,dyn,dyp,dxx,dyy,dxy,detaeta,gnorm;

  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) 
      cimg_map3x3(img,x,y,0,k,I) {

	dxn = Inc-Icc;
	dxp = Icc-Ipc;
	dx  = 0.5*(Inc-Ipc);
	dyn = Icn-Icc;
	dyp = Icc-Icp;
	dy  = 0.5*(Icn-Icp);
	gnorm = vector_norm(dx,dy);

	if(gnorm < 1e-5) { veloc(x,y,k) = 0.0; } else {
		dxx = Inc-2.0*Icc+Ipc;
		dyy = Icn-2.0*Icc+Icp;
		dxy = 0.25*(Inn+Ipp-Inp-Ipn);
		detaeta = ( std::pow((double)dx,2.0)*dxx + 2.0*dx*dy*dxy + std::pow((double)dy,2.0)*dyy ) / std::pow((double)gnorm,2.0);
        	veloc(x,y,k) =  std::sqrt(std::pow((double)minmod(dxn,dxp),2.0) + std::pow((double)minmod(dyn,dyp),2.0)) * cimg::sign(detaeta);
    }
    }

    img-=dt*veloc;
   
    if (disp) {
      if (disp->resized) disp->resize();
      img.display(*disp);
    }
 }	

  return img;
}

/** *****************************************************************

LEVEL-SETS AND SEGMENTATION

***************************************************************** **/


//! Distance function initialization
/**
   Given an image defining a curve given by the transition between negative and positive values, this function returns an distance function
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. 
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.
**/
CImg<T> get_distance_function(const int nb_iter=100, const float dt=0.0, CImgDisplay *disp=NULL) const {
  CImg<double> img(*this), veloc(*this,false);
  double a,b,c,d,S,G;
  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\n");
    std::fprintf(stderr,"\rIteration (distance function initialization) %d/%d\t\t",iter+1,nb_iter);

    cimg_mapXY(img,x,y) 

	if(img(x,y)!=0.0) { 

	  a=img(x,y)-img.neumann_pix2d(x-1,y);
	  b=img.neumann_pix2d(x+1,y)-img(x,y);
	  c=img(x,y)-img.neumann_pix2d(x,y-1);
	  d=img.neumann_pix2d(x,y+1)-img(x,y);
	  	  
	  S=(img(x,y)/std::pow(std::pow(img(x,y),2.0)+std::pow(0.05,2.0),0.5));
	  
	  if(img(x,y)>0.0)
	    G=std::pow(cimg::max(std::pow(positive_part(a),2.0),std::pow(negative_part(b),2.0))+
		  cimg::max(std::pow(positive_part(c),2.0),std::pow(negative_part(d),2.0)),0.5)-1.0;
	  else if(img(x,y)<0.0)
	    G=std::pow(cimg::max(std::pow(negative_part(a),2.0),std::pow(positive_part(b),2.0))+
		  cimg::max(std::pow(negative_part(c),2.0),std::pow(positive_part(d),2.0)),0.5)-1.0;
	  else
	    G=0.0;
	  
	  veloc(x,y) = -1.0 * S * G;

	} else {

	  veloc(x,y) = 0.0;

	}

    img+=dt*veloc;
  
    if (disp) {
      if (disp->resized) disp->resize();
      img.display(*disp);
    }
  }
  std::fprintf(stderr,"\n");
  return img;
}

CImg& distance_function(const int nb_iter=100, const float dt=0.0, CImgDisplay *disp=NULL) {
  return get_distance_function(nb_iter,dt,disp).swap(*this);
}

//! Mean curvature motion
/**
  \param level_curve = Set level which determine level set to make evolve
   General parameters
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param delta = Discontinuity parameter
   About updating the distance function
   \param df_frequency_iter = Frequency of update as a number of iterations
   \param df_nb_iter = Number of PDE iterations
   \param df_dt = PDE time step. 
   Disp
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.

**/

CImg<T> get_mean_curvature_motion(const double level_curve=125.0, const int nb_iter=100, const double dt=0.0, const int df_frequency_iter=20, const int df_nb_iter=20, const double df_dt=0.0, CImgDisplay *disp=NULL) const {
  double dx,dy,gnorm;
  CImg<float> img(*this), curvature(*this), veloc(*this,false), interface(*this);

  // Create a distance function associated to the level curve desired
  cimg_mapXY(img,x,y) if(img(x,y)<level_curve) img(x,y)=-1.0; else img(x,y)=1.0;
  img.distance_function(300,0.1,disp);
  
  // Create the image of the interface just for visualization
  cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
  CImgDisplay disp_interface(interface,"Evolving interface");


  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration (curve evolution) %d/%d\t\t",iter+1,nb_iter);

        curvature = img.get_curvature();

        cimg_mapXY(img,x,y) {

		dx = 0.5*(img.neumann_pix2d(x+1,y)-img.neumann_pix2d(x-1,y));
		dy = 0.5*(img.neumann_pix2d(x,y+1)-img.neumann_pix2d(x,y-1));
		gnorm = vector_norm(dx,dy);

		veloc(x,y) = gnorm * curvature(x,y);
	}

	img+=dt*veloc;

    	if (disp) {
		
      		if (disp->resized) disp->resize();
      		img.display(*disp);
    	}

	cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
	disp_interface.display(interface);

	if ((iter%df_frequency_iter) == 0) img.distance_function(df_nb_iter,df_dt,disp);
  }

  return img;
}

//! Geodesic active contours
/**
  \param my_image = Image to be segmented
  \param level_curve = Set level which determine level set to make evolve. that is initialization
   General parameters
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param delta = Discontinuity parameter
   About updating the distance function
   \param df_frequency_iter = Frequency of update as a number of iterations
   \param df_nb_iter = Number of PDE iterations
   \param df_dt = PDE time step. 
   Disp
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.

**/

CImg<T> get_mean_curvature_motion(const CImg<T> my_image, const double level_curve=125.0, const double alpha=10.0, const int nb_iter=100, const double dt=0.0, const int df_frequency_iter=20, const int df_nb_iter=20, const double df_dt=0.0, CImgDisplay *disp=NULL) const {

  double dx,dy,dxn,dxp,dyn,dyp,dxx,dyy,dxy,curvature,deltaplus,deltaminus,gnorm;

  CImg<float> img(*this), veloc(*this,false), interface(*this);

  // Create a distance function associated to the level curve desired
  cimg_mapXY(img,x,y) if(img(x,y)<level_curve) img(x,y)=-1.0; else img(x,y)=1.0;
  img.distance_function(300,0.1,disp);
  
  // Create the image of the interface just for visualization
  cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
  CImgDisplay disp_interface(interface,"Evolving interface");


  /* Transform original image into and "edge" image */
  CImgl<double> ima_grad = my_image.get_gradientXY(3);
  CImg<double> g_function(img);
  cimg_mapXY(img,x,y) g_function(x,y) = edge_detector(vector_norm(ima_grad[0](x,y),ima_grad[1](x,y)));
  CImgl<double> g_grad = g_function.get_gradientXY(3);

  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) 
      cimg_map3x3(img,x,y,0,k,I) {

	/* Curve derivatives */
	dxn = Inc-Icc;
	dxp = Icc-Ipc;
	dyn = Icn-Icc;
	dyp = Icc-Icp;
	dx  = 0.5*(Inc-Ipc);
	dy  = 0.5*(Icn-Icp);
	gnorm = vector_norm(dx,dy);
	dxx = Inc-2.0*Icc+Ipc;
	dyy = Icn-2.0*Icc+Icp;
	dxy = 0.25*(Inn+Ipp-Inp-Ipn);
	if(gnorm < 1e-5) curvature = 0.0; else { curvature = (dxx*dy*dy-2*dxy*dx*dy+dyy*dx*dx) / std::pow(gnorm,2.0); }
	deltaplus = std::sqrt( 	std::pow((double)cimg::max(dxp,0.0),2.0) + 
				std::pow((double)cimg::min(dxn,0.0),2.0) +
				std::pow((double)cimg::max(dxp,0.0),2.0) +
				std::pow((double)cimg::min(dxn,0.0),2.0) );
	deltaminus = std::sqrt( std::pow((double)cimg::max(dxn,0.0),2.0) + 
				std::pow((double)cimg::min(dxp,0.0),2.0) +
				std::pow((double)cimg::max(dxn,0.0),2.0) +
				std::pow((double)cimg::min(dxp,0.0),2.0) );
		
	veloc(x,y,k) =  my_image(x,y) * curvature * gnorm +
			alpha * ( cimg::max(g_function(x,y),0.0) * deltaplus + cimg::min(g_function(x,y),0.0) * deltaminus ) | 
			cimg::max(g_grad[0](x,y),0.0) * dxp + cimg::min(g_grad[0](x,y),0.0) * dxn +
			cimg::max(g_grad[1](x,y),0.0) * dyp + cimg::min(g_grad[1](x,y),0.0) * dyn;
			
    }

    img+=dt*veloc;


    	if (disp) {
		
      		if (disp->resized) disp->resize();
      		img.display(*disp);
    	}

	cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
	disp_interface.display(interface);

	if ((iter%df_frequency_iter) == 0) img.distance_function(df_nb_iter,df_dt,disp);
  }

  return img;
}


//! Test

CImg<T> get_test(const double level=100.0) {
  CImg<double> img(*this);
  cimg_mapXY(img,x,y) if(img(x,y)<level) img(x,y)=0.0; else img(x,y)=255.0;
  return img;
}

CImg& test(const double level=100.0) {
  return get_test(level).swap(*this);
}
