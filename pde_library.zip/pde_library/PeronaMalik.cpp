#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  cimg_usage("Perona-Malik model");
  const char* input   = cimg_option("-i","PeronaMalik.pgm","Input image");
  const double gnoise = cimg_option("-noise",30.0,"Variance of the additive Gaussian noise");
  const double dt     = cimg_option("-dt",0.25,"Time step (if negative, automatic selection)");
  const int itm       = cimg_option("-it",50,"Number of Iterations");
  const double dta    = cimg_option("-delta",20,"Discontinuity parameter");

  CImg<float> img(input);

  if (gnoise > 0.0) {
	cout<<"Adding a Gaussian noise to the input"<<endl;
	img.noise(gnoise);
  }

  CImgDisplay disp_ini(img,"Original image"),disp(img,"Perona-Malik model");
  
  img.get_perona_malik2d(itm,dt,dta,&disp);
  
  while (!disp.closed) disp.wait();

  return 0;
}
