#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  cimg_usage("Total Variation");
  const char* input = cimg_option("-i","ima/checker.pgm","Input image");
  const double dt   = cimg_option("-dt",0.25,"Time step (if negative, automatic selection)");
  const int itm     = cimg_option("-it",50,"Number of Iterations");
  const double dta  = cimg_option("-delta",30,"Discontinuity parameter");
  const double eps  = cimg_option("-e",1.0,"Absolute value is approximated by sqrt(e+s*s).");

  CImg<float> img(input);
  CImgDisplay disp(img,"Total Variation");
  
  img.get_tv2d(itm,dt,dta,eps,&disp);
  
  while (!disp.closed) disp.wait();

  return 0;
}
