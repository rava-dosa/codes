#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;

static double weight(double u,double eps) { return 1.0/sqrt(eps+u*u); }

int main(int argc,char **argv) {

    // Parsing options
    cimg_usage("Half Quadratic Minimization (Charbonnier etal)");  
    /// I/O
    const char* input      = cimg_option("-i","HalfQuadraticMinimization.pgm","Input image");
    const bool initialize  = cimg_option("-init",true,"If true, start with null image");
    const double noise     = cimg_option("-noise",20.0,"Add Gaussian noise to the input image?");
    const char* output     = cimg_option("-o","/tmp/default.pgm","Output image");
    /// Parameters defining the functional
    const double lambda    = cimg_option("-l",0.5,"Fidelity attach term");
    const double delta     = cimg_option("-discont",5.0,"Discontinuity parameter");
    const double eps       = cimg_option("-epsilon",0.1,"epsilon (approximation of TV derivative)");
    /// Parameters defining the algorithm
    const int         itm  = cimg_option("-it",50,"Number of Iterations");
    const double EvolutionThreshold = cimg_option("-threshold",0.01,"[linear part] Threshold for convergence");
    const double dt        = cimg_option("-dt",0.01,"[linear part] Time step");
    const int       itmcv  = cimg_option("-itmax",30,"[linear part] Maximum Number of Iterations for each minimization step");
    /// Displays
    const int ZoomingFactor       = cimg_option("-zoom",3,"Zooming Factor for display");
    
    // Read image and declarations
    CImg<float>   img(input); 
    if(noise>0.0) img.noise(noise); 
    cimg_mapXY(img,x,y) { if(img(x,y)<0.0) img(x,y)=0.0; if(img(x,y)>255.0) img(x,y)=255.0; } // Check that remains in bounds

    CImg<float> imaRead(img), veloc(img,false), Luminance(img.dimx(),img.dimy(),1,1,0.0);
    CImg<float> weightE(img.dimx(),img.dimy(),1,1,0.0), weightW(weightE), weightN(weightE), weightS(weightE), weightNE(weightE), weightNW(weightE), weightSW(weightE), weightSE(weightE), weightMix(img.dimx(),img.dimy(),1,1,0.0);
    float Evolution,SumWeight;

    if ( initialize == true ) img.fill(0.0);
    CImgDisplay disp_ini(img.get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor),"Initial image",1),
	disp(img.get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor),"Restoration",0),	dispWeight(weightMix.get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor),"Weight",1);

    disp_ini.display(imaRead.get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor));

    // Half quadratic minimization
    for (uint iter=0; !disp.closed && disp.key!=cimg::keyQ && iter<itm; iter++) {

	cout<<"Iteration "<<iter<<endl;

	cout<<"   Minimize linearized energy"<<endl;
	// Minimization when weight is fixed
	Evolution = 100.0;
    	for (uint itercv=0; !disp.closed && disp.key!=cimg::keyQ && itercv<itmcv && Evolution>EvolutionThreshold; itercv++) {

		cimg_mapXYV(img,x,y,k) { 
	
		SumWeight = weightN(x,y)+weightS(x,y)+weightE(x,y)+weightW(x,y)+weightNE(x,y)+weightNW(x,y)+weightSE(x,y)+weightSW(x,y);
		
		veloc(x,y,k) = 
			weightN(x,y)  * img.neumann_pix2d(x  ,y+1) + 
			weightS(x,y)  * img.neumann_pix2d(x  ,y-1) + 
			weightE(x,y)  * img.neumann_pix2d(x+1,y  ) + 
			weightW(x,y)  * img.neumann_pix2d(x-1,y  ) +
			weightNE(x,y) * img.neumann_pix2d(x+1,y+1) +
			weightNW(x,y) * img.neumann_pix2d(x-1,y+1) +
			weightSE(x,y) * img.neumann_pix2d(x+1,y-1) +
			weightSW(x,y) * img.neumann_pix2d(x-1,y-1) -
			SumWeight * img(x,y) - 
			lambda * ( img(x,y) - imaRead(x,y,0,k) );
	
		}
		img += veloc*dt;
		disp.display(img.get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor));
		Evolution = veloc.norm(-1)/img.norm(-1);
		cout<<"      Step "<<itercv<<": Normalized norm of the difference = "<<Evolution<<endl;

	} // EOL itercv


	cout<<"   Estimate weights"<<endl;
	// Creation de l'image de luminance
	cimg_mapXY(img,x,y) {
		Luminance(x,y) = 0.0;
		cimg_mapV(img,v) Luminance(x,y) += img(x,y,0,v);
		Luminance(x,y) /= img.dimv();
	}
	// Estimate weights
	cimg_mapXY(Luminance,x,y) {
		weightN(x,y)  = weight((Luminance.neumann_pix2d(x  ,y+1) - Luminance(x,y))/delta,eps);
		weightS(x,y)  = weight((Luminance.neumann_pix2d(x  ,y-1) - Luminance(x,y))/delta,eps);
		weightE(x,y)  = weight((Luminance.neumann_pix2d(x+1,y  ) - Luminance(x,y))/delta,eps);
		weightW(x,y)  = weight((Luminance.neumann_pix2d(x-1,y  ) - Luminance(x,y))/delta,eps);
		weightNE(x,y) = weight((Luminance.neumann_pix2d(x+1,y+1) - Luminance(x,y))/delta,eps);
		weightNW(x,y) = weight((Luminance.neumann_pix2d(x-1,y+1) - Luminance(x,y))/delta,eps);
		weightSE(x,y) = weight((Luminance.neumann_pix2d(x+1,y-1) - Luminance(x,y))/delta,eps);
		weightSW(x,y) = weight((Luminance.neumann_pix2d(x-1,y-1) - Luminance(x,y))/delta,eps);
		weightMix(x,y) = cimg::min(weightN(x,y),weightE(x,y));
	}
        dispWeight.display(weightMix.get_normalize(0.0,255.0).get_resize(img.dimx()*ZoomingFactor,img.dimy()*ZoomingFactor));
	weightMix.print();
	weightMix.save_inr("/tmp/weight.inr");


    }

    // Save result
    cout<<"... File "<<output<<" saved"<<endl;
    img.save(output);
    while (!disp.closed && !disp.button )  disp.wait();
    return 0;
}
