//! Geodesic active contours
/**
  \param my_image = Image to be segmented
  \param level_curve = Set level which determine level set to make evolve. that is initialization
   General parameters
   \param nb_iter = Number of PDE iterations
   \param dt = PDE time step. If dt<0, -dt represents the maximum PDE velocity that will be
   applied on image pixels (adaptative time step)
   \param delta = Discontinuity parameter
   About updating the distance function
   \param df_frequency_iter = Frequency of update as a number of iterations
   \param df_nb_iter = Number of PDE iterations
   \param df_dt = PDE time step. 
   Disp
   \param disp = Display used to show the PDE evolution. If disp==NULL, no display is performed.

**/

CImg<T> get_mean_curvature_motion(const CImg<T> my_image, const double level_curve=125.0, const double alpha=10.0, const int nb_iter=100, const double dt=0.0, const int df_frequency_iter=20, const int df_nb_iter=20, const double df_dt=0.0, CImgDisplay *disp=NULL) const { 

  double dx,dy,dxn,dxp,dyn,dyp,dxx,dyy,dxy,curvature,deltaplus,deltaminus,gnorm;

  CImg<float> img(*this), veloc(*this,false), interface(*this);

  // Create a distance function associated to the level curve desired
  cimg_mapXY(img,x,y) if(img(x,y)<level_curve) img(x,y)=-1.0; else img(x,y)=1.0;
  img.distance_function(300,0.1,disp);
  
  // Create the image of the interface just for visualization
  cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
  CImgDisplay disp_interface(interface,"Evolving interface");


  /* Transform original image into and "edge" image */
  CImgl<double> ima_grad = my_image.get_gradientXY(3);
  CImg<double> g_function(img);
  cimg_mapXY(img,x,y) g_function(x,y) = edge_detector(vector_norm(ima_grad[0](x,y),ima_grad[1](x,y)));
  CImgl<double> g_grad = g_function.get_gradientXY(3);

  for (int iter=0; iter<nb_iter; iter++) {
    std::fprintf(stderr,"\rIteration %d/%d\t\t",iter+1,nb_iter);
    
    CImg_3x3(I,float);
    cimg_mapV(img,k) 
      cimg_map3x3(img,x,y,0,k,I) {

	/* Curve derivatives */
	dxn = Inc-Icc;
	dxp = Icc-Ipc;
	dyn = Icn-Icc;
	dyp = Icc-Icp;
	dx  = 0.5*(Inc-Ipc);
	dy  = 0.5*(Icn-Icp);
	gnorm = vector_norm(dx,dy);
	dxx = Inc-2.0*Icc+Ipc;
	dyy = Icn-2.0*Icc+Icp;
	dxy = 0.25*(Inn+Ipp-Inp-Ipn);
	if(gnorm < 1e-5) curvature = 0.0; else { curvature = (dxx*dy*dy-2*dxy*dx*dy+dyy*dx*dx) / std::pow(gnorm,2.0); }
	deltaplus = std::sqrt( 	std::pow((double)cimg::max(dxp,0.0),2.0) + 
				std::pow((double)cimg::min(dxn,0.0),2.0) +
				std::pow((double)cimg::max(dxp,0.0),2.0) +
				std::pow((double)cimg::min(dxn,0.0),2.0) );
	deltaminus = std::sqrt( std::pow((double)cimg::max(dxn,0.0),2.0) + 
				std::pow((double)cimg::min(dxp,0.0),2.0) +
				std::pow((double)cimg::max(dxn,0.0),2.0) +
				std::pow((double)cimg::min(dxp,0.0),2.0) );
		
	veloc(x,y,k) =  my_image(x,y) * curvature * gnorm +
			alpha * ( cimg::max(g_function(x,y),0.0) * deltaplus + cimg::min(g_function(x,y),0.0) * deltaminus ) | 
			cimg::max(g_grad[0](x,y),0.0) * dxp + cimg::min(g_grad[0](x,y),0.0) * dxn +
			cimg::max(g_grad[1](x,y),0.0) * dyp + cimg::min(g_grad[1](x,y),0.0) * dyn;
			
    }

    img+=dt*veloc;


    	if (disp) {
		
      		if (disp->resized) disp->resize();
      		img.display(*disp);
    	}

	cimg_mapXY(interface,x,y) if(img(x,y)<0.0) interface(x,y)=0.0; else interface(x,y)=255.0;
	disp_interface.display(interface);

	if ((iter%df_frequency_iter) == 0) img.distance_function(df_nb_iter,df_dt,disp);
  }

  return img;
}


//! Test

CImg<T> get_test(const double level=100.0) {
  CImg<double> img(*this);
  cimg_mapXY(img,x,y) if(img(x,y)<level) img(x,y)=0.0; else img(x,y)=255.0;
  return img;
}

CImg& test(const double level=100.0) {
  return get_test(level).swap(*this);
}
