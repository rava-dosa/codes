#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  cimg_usage("Shock-Filters model");
  const char* input   = cimg_option("-i","ShockFilters.pgm","Input image");
  const double dt     = cimg_option("-dt",0.1,"Time step (if negative, automatic selection)");
  const int itm       = cimg_option("-it",300,"Number of Iterations");

  CImg<float> img(input);
  CImgDisplay disp_ini(img,"Original image"),disp(img,"Shock Filters model");
  
  img.get_shock_filters(itm,dt,&disp);
  
  while (!disp.closed) disp.wait();

  return 0;
}
