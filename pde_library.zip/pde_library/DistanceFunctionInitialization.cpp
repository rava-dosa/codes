#define cimg_plugin "Pde.h"
#include "CImg.h"
#include <iostream>

using namespace std;
using namespace cimg_library;


using namespace cimg_library;

int main(int argc,char **argv) {

  cimg_usage("Distance Function Initialization");
  const char* input = cimg_option("-i","DistanceFunctionInitialization.pgm","Input image");
  const float level = cimg_option("-l",100.0,"Level set of the input image considered (will modify image in [-1,+1])");
  const double dt   = cimg_option("-dt",0.25,"Time step");
  const int itm     = cimg_option("-it",50,"Number of Iterations");

  CImg<float> img(input);

  cimg_mapXY(img,x,y) if(img(x,y)<level) img(x,y)=-1.0; else img(x,y)=1.0;

  CImgDisplay disp(img,"Distance Function");

  img.get_distance_function(itm,dt,&disp);

  while (!disp.closed) disp.wait();

  return 0;
}
